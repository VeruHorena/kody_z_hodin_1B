using System;

class MainClass {
    public static void Main (string[] args) {
        
      
      Console.WriteLine ("Vlož své jméno :");
        string jmeno = Console.ReadLine();
        Console.WriteLine ("Ať žije " + jmeno + "!");
    
      
     
      }
}