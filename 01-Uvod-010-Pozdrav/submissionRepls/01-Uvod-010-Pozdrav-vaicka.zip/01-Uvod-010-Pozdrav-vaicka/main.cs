using System;

class MainClass {
    public static void Main (string[] args) {
        Console.WriteLine ("Vlož své jméno :");
        Console.WriteLine ("Ať žije " + Console.ReadLine() + "!");

    }
}