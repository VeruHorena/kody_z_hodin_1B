# Pozdrav

Tento program by se měl uživatele zeptat na jméno a pak jej pozdravit. 

Z nějakého důvodu ale nechodí. Dokážete jej opravit?