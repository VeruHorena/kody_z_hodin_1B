using System;

class Program {
    public static void Main(string[] args) {
        Console.WriteLine("Введите число:");
        int number = int.Parse(Console.ReadLine());

        for (int i = -number + 1; i < number; i++) {
            int currentNumber = i < 0 ? -i : i;

            for (int j = 0; j < currentNumber; j++) {
                Console.Write(number);
                if (j != currentNumber - 1) {
                    Console.Write(" ");
                }
            }
            if (i != number - 1) {
                Console.Write(" "); // Добавляем пробел между частями паттерна
            }
        }
        Console.WriteLine();
    }
}
