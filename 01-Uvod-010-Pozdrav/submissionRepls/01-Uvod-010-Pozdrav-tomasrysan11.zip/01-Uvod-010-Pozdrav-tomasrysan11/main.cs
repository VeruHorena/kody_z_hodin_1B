using System;

class MainClass {
    public static void Main (string[] args) {
        Console.WriteLine ("Vlož své jméno :");
        int jmeno = Console.ReadLine();
        Console.WriteLine ("Ať žije " + jmeno + "!");
    }
}